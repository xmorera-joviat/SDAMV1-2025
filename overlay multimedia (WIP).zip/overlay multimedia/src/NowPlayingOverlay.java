import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Timer;
import java.util.TimerTask;

public class NowPlayingOverlay {
    private static JLabel label;
    private static JFrame frame;
    private static String lastTitle = "";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(NowPlayingOverlay::createOverlay);
        startUpdatingTitle();
    }

    private static void createOverlay() {
        frame = new JFrame();
        frame.setUndecorated(true);
        frame.setAlwaysOnTop(true);
        frame.setBackground(new Color(0, 0, 0, 128)); // Fondo semi-transparente

        label = new JLabel("Reproduciendo: Desconocido", SwingConstants.CENTER);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 14));

        frame.add(label);
        frame.pack(); // Ajusta el tamaño del frame al contenido
        frame.setLocation(10, 10);
        frame.setVisible(true);
    }

    private static void startUpdatingTitle() {
        Timer timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                String title = getNowPlayingTitle();
                if (title != null && !title.isEmpty() && !title.equals(lastTitle)) {
                    lastTitle = title;
                    updateOverlay(title);
                }
            }
        }, 0, 2000); // Se actualiza cada 2 segundos
    }

    private static String getNowPlayingTitle() {
        try {
            ProcessBuilder builder = new ProcessBuilder(
                "powershell", "-Command", "(Get-Process -Name explorer | Get-ModernMediaSession).NowPlaying"
            );
            builder.redirectErrorStream(true);
            Process process = builder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line.trim()).append(" ");
            }
            reader.close();

            String result = output.toString().replaceAll(".*Get-ModernMediaSession.*", "").trim();
            return result.isEmpty() ? "Reproduciendo: Desconocido" : "Reproduciendo: " + result;
        } catch (Exception e) {
            e.printStackTrace();
            return "Reproduciendo: Error";
        }
    }

    private static void updateOverlay(String title) {
        SwingUtilities.invokeLater(() -> {
            label.setText(title);
            frame.pack(); // Ajustar el tamaño al nuevo texto
        });
    }
}
