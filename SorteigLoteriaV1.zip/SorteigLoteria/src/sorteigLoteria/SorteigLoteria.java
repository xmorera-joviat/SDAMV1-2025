package sorteigLoteria;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class SorteigLoteria extends JFrame {
    
    private JTextField num1Field, num2Field, num3Field;
    private JButton sorteigButton;
    private JLabel resultatLabel;

    public SorteigLoteria() {
        // Configuració de la finestra
        setTitle("Sorteig de Loteria");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Crear els components
        JLabel label1 = new JLabel("Introdueix el primer número (0-9):");
        num1Field = new JTextField(2);
        JLabel label2 = new JLabel("Introdueix el segon número (0-9):");
        num2Field = new JTextField(2);
        JLabel label3 = new JLabel("Introdueix el tercer número (0-9):");
        num3Field = new JTextField(2);
        
        sorteigButton = new JButton("Sorteig");
        resultatLabel = new JLabel("Resultat:");

        // Afegir els components a la finestra
        add(label1);
        add(num1Field);
        add(label2);
        add(num2Field);
        add(label3);
        add(num3Field);
        add(sorteigButton);
        add(resultatLabel);

        // Acció al prémer el botó de sorteig
        sorteigButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Llegir els números de l'usuari
                    int num1 = Integer.parseInt(num1Field.getText());
                    int num2 = Integer.parseInt(num2Field.getText());
                    int num3 = Integer.parseInt(num3Field.getText());

                    // Comprovar que els números estan dins de l'interval permès
                    if (num1 < 0 || num1 > 9 || num2 < 0 || num2 > 9 || num3 < 0 || num3 > 9) {
                        resultatLabel.setText("Els números han de ser entre 0 i 9.");
                        return;
                    }

                    // Generar els números aleatoris per al sorteig
                    Random random = new Random();
                    int sorteig1 = random.nextInt(10);
                    int sorteig2 = random.nextInt(10);
                    int sorteig3 = random.nextInt(10);

                    // Mostrar el resultat del sorteig
                    String sorteigResult = "Sorteig: " + sorteig1 + " " + sorteig2 + " " + sorteig3;
                    String missatge = "";

                 // Comprovació dels encerts
                    int encerts = 0;

                    // Comprovar el tercer número
                    if (num3 == sorteig3) {
                        encerts++;
                        // Si el tercer número és correcte, comprovar el segon número
                        if (num2 == sorteig2) {
                            encerts++;
                            // Si el segon número també és correcte, comprovar el primer número
                            if (num1 == sorteig1) {
                                encerts++;
                            }
                        }
                    }

                    // Mostrar el missatge amb els encerts
                    switch (encerts) {
                        case 3:
                            missatge = "Tens 3 encerts! Felicitats!";
                            break;
                        case 2:
                            missatge = "Tens 2 encerts!";
                            break;
                        case 1:
                            missatge = "Tens 1 encert!";
                            break;
                        default:
                            missatge = "No has encertat.";
                            break;
                    }

                    // Actualitzar el resultat a la finestra
                    resultatLabel.setText(sorteigResult + " " + missatge);

                } catch (NumberFormatException ex) {
                    resultatLabel.setText("Introdueix números vàlids.");
                }
            }
        });
    }

    public static void main(String[] args) {
        // Crear i mostrar la finestra
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SorteigLoteria().setVisible(true);
            }
        });
    }
}